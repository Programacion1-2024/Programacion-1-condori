﻿using Microsoft.VisualStudio.TestPlatform.ObjectModel.Client;
using System;

namespace ResistorColorTrio__Facil_
{
    /*
    Consigna:
        Si quieres construir algo con una Raspberry Pi, probablemente usarás resistencias . Para este ejercicio, solo necesitas saber tres cosas sobre ellas:
        Cada resistencia tiene un valor de resistencia.
        Las resistencias son pequeñas, tan pequeñas que si se imprimiera el valor de resistencia en ellas, sería difícil leerlo. Para solucionar este problema, los fabricantes imprimen bandas con códigos de colores en las resistencias para indicar sus valores de resistencia.
        Cada banda actúa como un dígito de un número. Por ejemplo, si imprimieran una banda marrón (valor 1) seguida de una banda verde (valor 5), se traduciría al número 15. En este ejercicio, creará un programa útil para que no tenga que recordar los valores de las bandas. El programa tomará 3 colores como entrada y emitirá el valor correcto, en ohmios. Las bandas de color están codificadas de la siguiente manera:

        black: 0
        brown: 1
        red: 2
        orange: 3
        yellow: 4
        green: 5
        blue: 6
        violet: 7
        grey: 8
        white: 9

        En Resistor Color Duo decodificaste los dos primeros colores. Por ejemplo: orange-orange obtuvo el valor principal 33. El tercer color representa la cantidad de ceros que se deben agregar al valor principal. El valor principal más los ceros nos da un valor en ohmios. Para el ejercicio no importa cuántos ohmios sean realmente. Por ejemplo:

        orange-orange-black sería 33 y ningún cero, lo que se convierte en 33 ohmios.
        orange-orange-red seria 33 y 2 ceros, lo que se convierte en 3300 ohmios.
        orange-orange-orange sería 33 y 3 ceros, lo que se convierte en 33000 ohmios.

        (Si las matemáticas son lo tuyo, quizás quieras pensar en los ceros como exponentes de 10. Si las matemáticas no son lo tuyo, usa los ceros. En realidad es lo mismo, sólo que en un lenguaje sencillo en lugar de jerga matemática).

        Este ejercicio consiste en traducir los colores en una etiqueta:
            "... ohmios"
        Por lo tanto, una entrada "orange", "orange", "black" debería devolver:
            "33 ohmios"

        Cuando se trata de resistencias más grandes, se utiliza un prefijo métrico para indicar una magnitud mayor de ohmios, como por ejemplo "kiloohms". Esto es similar a decir "2 kilómetros" en lugar de "2000 metros", o "2 kilogramos" en lugar de "2000 gramos".
        
        Por ejemplo, una entrada de "orange", "orange", "orange" debería devolver:
            "33 kiloohmios"
    */

    public static class ResistorColorTrio
    {
        public static string Label(string[] colors)
        {
          var Colores = new Dictionary<string, int>()
          {
            { "black", 0 },
            { "brown", 1 },
            { "red", 2 },
            { "orange", 3 },
            { "yellow", 4 },
            { "green", 5 },
            { "blue", 6 },
            { "violet", 7 },
            { "grey", 8 },
            { "white", 9 }
          };

            
            int PrimerDigito = Colores[colors[0]];
            int SegundoDigito = Colores[colors[1]];

            
            int multiplicador = (int)Math.Pow(10, Colores[colors[2]]);

            
            int resistencia = (PrimerDigito * 10 + SegundoDigito) * multiplicador;

           
            if (resistencia >= 1000)
            {
                return (resistencia / 1000) + " kiloohms";
            }
            else
            {
                return resistencia + " ohms";
            }

        }
    }

}

https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.dictionary-2?view=net-7.0*/
https://learn.microsoft.com/en-us/dotnet/api/system.math.pow?view=net-7.0
