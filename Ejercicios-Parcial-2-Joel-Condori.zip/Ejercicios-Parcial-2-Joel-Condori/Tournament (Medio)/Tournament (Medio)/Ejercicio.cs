﻿using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using System;
using System.IO;
using System.Text;

public static class Tournament
{
    /*
    Consigna:
        Cuente los resultados de una pequeña competición de fútbol.

        A partir de un archivo de entrada que contiene qué equipo jugó contra qué equipo y cuál fue el resultado, cree un archivo con una tabla como esta:

        Team                           | MP |  W |  D |  L |  P
        Devastating Donkeys            |  3 |  2 |  1 |  0 |  7
        Allegoric Alaskans             |  3 |  2 |  0 |  1 |  6
        Blithering Badgers             |  3 |  1 |  0 |  2 |  3
        Courageous Californians        |  3 |  0 |  1 |  2 |  1

        ¿Qué significan esas abreviaturas?

        MP: Partidos jugados
        W: Partidos ganados
        D: Partidos Empatados
        L: Partidos perdidos
        P: Puntos

        Una victoria le otorga al equipo 3 puntos. Un empate le otorga 1. Una derrota le otorga 0.

        El resultado se ordena por puntos, en orden descendente. En caso de empate, los equipos se ordenan alfabéticamente.

        Su programa de conteo recibirá una entrada similar a la siguiente:
            Allegoric Alaskans;Blithering Badgers;win
            Devastating Donkeys;Courageous Californians;draw
            Devastating Donkeys;Allegoric Alaskans;win
            Courageous Californians;Blithering Badgers;loss
            Blithering Badgers;Devastating Donkeys;loss
            Allegoric Alaskans;Courageous Californians;win

        El resultado del partido se refiere al primer equipo que aparece en la lista. Así que esta línea:
            Allegoric Alaskans;Blithering Badgers;win
        significa que los Allegoric Alaskans vencieron a los Blithering Badgers.

        Esta linea:
            Courageous Californians;Blithering Badgers;loss
        significa que los Blithering Badgers vencieron a los Courageous Californians.

        Y esta linea:
            Devastating Donkeys;Courageous Californians;draw
        significa que los Devastating Donkeys y los Courageous Californians empataron.

    */

    public static string Tally(string input)
    {
        var teamStats = new Dictionary<string, int[]>();

        
        var lines = input.Split('\n');

        foreach (var line in lines)
        {
            
            var parts = line.Split(';');

            if (parts.Length == 3)
            {
                var team1 = parts[0].Trim(); 
                var team2 = parts[1].Trim(); 
                var result = parts[2].Trim(); 

                
                if (!teamStats.ContainsKey(team1))
                {
                    teamStats[team1] = new int[5]; 
                }
                if (!teamStats.ContainsKey(team2))
                {
                    teamStats[team2] = new int[5];
                }

                
                teamStats[team1][0]++; 
                teamStats[team2][0]++; 

                if (result == "win")
                {
                    teamStats[team1][1]++; 
                    teamStats[team1][4] += 3; 
                    teamStats[team2][3]++;
                }
                else if (result == "loss")
                {
                    teamStats[team2][1]++; 
                    teamStats[team2][4] += 3; 
                    teamStats[team1][3]++; 
                }
                else if (result == "draw")
                {
                    teamStats[team1][2]++; 
                    teamStats[team2][2]++; 
                    teamStats[team1][4]++; 
                    teamStats[team2][4]++; 
                }
            }
        }


     
        var sortedTeamsByPoints = teamStats.OrderByDescending(t => t.Value[4]);

        var sortedTeams = sortedTeamsByPoints.ThenBy(t => t.Key);



        var resultTable = "Team                           | MP |  W |  D |  L |  P\n";

        foreach (var team in sortedTeams)
        {
            var line = $"{team.Key.PadRight(30)} |  {team.Value[0]} |  {team.Value[1]} |  {team.Value[2]} |  {team.Value[3]} |  {team.Value[4]}";
            resultTable += line + "\n";
        }

        return resultTable.TrimEnd('\n');
    }
}

https://learn.microsoft.com/en-us/dotnet/api/system.string.split?view=net-8.0
https://learn.microsoft.com/en-us/dotnet/api/system.string.split?view=net-8.0
https://learn.microsoft.com/en-us/dotnet/api/system.string.trim?view=net-8.0
https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.dictionary-2.containskey?view=net-8.0
https://learn.microsoft.com/en-us/dotnet/api/system.linq.enumerable.orderbydescending?view=net-8.0
https://learn.microsoft.com/en-us/dotnet/api/system.linq.enumerable.thenby?view=net-8.0
https://learn.microsoft.com/en-us/dotnet/api/system.string.trimend?view=net-8.0